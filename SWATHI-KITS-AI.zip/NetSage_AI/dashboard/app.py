import streamlit as st
import sys
import os
import csv
from datetime import datetime

# Allow importing files from src
sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from src.demo_diagnosis import diagnose_case


st.set_page_config(
    page_title="NetSage AI",
    page_icon="🌐",
    layout="wide"
)

st.title("🌐 NetSage AI")
st.subheader("Cisco Network Troubleshooter")

st.write(
    "AI-assisted Cisco network troubleshooting with "
    "human verification."
)

st.divider()

# ============================================================
# INPUT SECTION
# ============================================================

st.header("🔍 Network Information")

symptom = st.text_area(
    "Network Symptom",
    placeholder="Example: PC cannot communicate with devices in VLAN 10"
)

topology = st.text_area(
    "Topology Information",
    placeholder="Example: PC1 is connected to Switch1 through FastEthernet0/1"
)

show_output = st.text_area(
    "Cisco Show-Command Output",
    height=200,
    placeholder="Paste Cisco show-command output here..."
)

diagnose = st.button(
    "🔎 Diagnose Network",
    type="primary"
)

# ============================================================
# DIAGNOSIS
# ============================================================

if diagnose:

    if not symptom or not topology or not show_output:

        st.warning(
            "Please enter the symptom, topology information, "
            "and Cisco show-command output."
        )

    else:

        with st.spinner("Analyzing network problem..."):

            result = diagnose_case(
                symptom,
                topology,
                show_output
            )

        # Store result in session
        st.session_state["diagnosis"] = result
        st.session_state["symptom"] = symptom
        st.session_state["topology"] = topology
        st.session_state["show_output"] = show_output


# ============================================================
# DISPLAY DIAGNOSIS
# ============================================================

if "diagnosis" in st.session_state:

    result = st.session_state["diagnosis"]

    st.divider()

    st.header("🧠 AI Diagnosis")

    st.subheader("Root Cause")

    if result["confidence"] == "High":
        st.success(result["root_cause"])
    else:
        st.warning(result["root_cause"])

    # --------------------------------------------------------
    # METRICS
    # --------------------------------------------------------

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric(
            "Confidence",
            result["confidence"]
        )

    with col2:
        st.metric(
            "OSI Layer",
            result["osi_layer"]
        )

    with col3:

        if result["human_review_required"]:
            st.metric(
                "Human Review",
                "Required"
            )
        else:
            st.metric(
                "Human Review",
                "Not Required"
            )

    # --------------------------------------------------------
    # EVIDENCE
    # --------------------------------------------------------

    st.subheader("📌 Evidence")

    for evidence in result["evidence"]:
        st.write("• " + evidence)

    # --------------------------------------------------------
    # COMMANDS
    # --------------------------------------------------------

    st.subheader("💻 Recommended Cisco Commands")

    for command in result["next_command"]:
        st.code(command)

    # --------------------------------------------------------
    # FIX STEPS
    # --------------------------------------------------------

    st.subheader("🔧 Recommended Fix Steps")

    for i, step in enumerate(result["fix_steps"], 1):
        st.write(f"**{i}.** {step}")

    # ========================================================
    # HUMAN REVIEW
    # ========================================================

    st.divider()

    st.header("👨‍💻 Human Review")

    st.info(
        "A network administrator must review the AI diagnosis "
        "before any configuration change is applied."
    )

    decision = st.radio(
        "Human Decision",
        [
            "Accepted",
            "Edited"
        ],
        horizontal=True
    )

    correction = ""

    if decision == "Edited":

        correction = st.text_area(
            "Human Correction",
            placeholder="Enter the corrected diagnosis..."
        )

    # --------------------------------------------------------
    # SAVE REVIEW
    # --------------------------------------------------------

    if st.button("💾 Save Human Review"):

        if decision == "Edited" and not correction.strip():

            st.warning(
                "Please enter the human correction."
            )

        else:

            log_file = os.path.join(
                os.path.dirname(__file__),
                "..",
                "logs",
                "cases.csv"
            )

            log_file = os.path.abspath(log_file)

            os.makedirs(
                os.path.dirname(log_file),
                exist_ok=True
            )

            file_exists = os.path.exists(log_file)

            with open(
                log_file,
                "a",
                newline="",
                encoding="utf-8"
            ) as file:

                writer = csv.writer(file)

                if not file_exists:

                    writer.writerow([
                        "case_id",
                        "ai_diagnosis",
                        "human_decision",
                        "human_correction",
                        "timestamp"
                    ])

                writer.writerow([
                    datetime.now().strftime("%Y%m%d%H%M%S"),
                    result["root_cause"],
                    decision,
                    correction,
                    datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                ])

            st.success(
                "✅ Human review saved successfully."
            )

    # --------------------------------------------------------
    # WARNING
    # --------------------------------------------------------

    st.warning(
        "⚠️ Do not apply network configuration changes "
        "automatically. Human verification is required."
    )
    # ============================================================
# MODEL EVALUATION
# ============================================================

st.divider()

st.header("📊 Model Evaluation")

results_file = os.path.join(
    os.path.dirname(__file__),
    "..",
    "logs",
    "case_results.csv"
)

results_file = os.path.abspath(results_file)

if os.path.exists(results_file):

    import pandas as pd

    results_df = pd.read_csv(results_file)

    total_cases = len(results_df)
    correct_cases = 0

    if "status" in results_df.columns:
        correct_cases = (
            results_df["status"]
            .astype(str)
            .str.upper()
            .eq("CORRECT")
            .sum()
        )

    elif "correct" in results_df.columns:
        correct_cases = (
            results_df["correct"]
            .astype(str)
            .str.lower()
            .isin(["true", "1", "yes"])
            .sum()
        )

    incorrect_cases = total_cases - correct_cases

    if total_cases > 0:
        accuracy = (correct_cases / total_cases) * 100
    else:
        accuracy = 0

    # Metrics
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            "Total Cases",
            total_cases
        )

    with col2:
        st.metric(
            "Correct Cases",
            correct_cases
        )

    with col3:
        st.metric(
            "Incorrect Cases",
            incorrect_cases
        )

    with col4:
        st.metric(
            "Accuracy",
            f"{accuracy:.2f}%"
        )

    st.subheader("📋 Case-by-Case Results")

    st.dataframe(
        results_df,
        use_container_width=True
    )

else:

    st.info(
        "No evaluation results found. "
        "Run the 30-case test first."
    )
    # ============================================================
# HUMAN REVIEW HISTORY
# ============================================================

st.divider()

st.header("📋 Human Review History")

review_file = os.path.join(
    os.path.dirname(__file__),
    "..",
    "logs",
    "cases.csv"
)

review_file = os.path.abspath(review_file)

if os.path.exists(review_file):

    import pandas as pd

    review_df = pd.read_csv(review_file)

    if len(review_df) > 0:

        st.dataframe(
            review_df,
            use_container_width=True
        )

        st.caption(
            f"Total human reviews recorded: {len(review_df)}"
        )

    else:

        st.info("No human reviews have been recorded yet.")

else:

    st.info("No human review history found.")