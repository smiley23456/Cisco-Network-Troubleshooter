import csv
import os
from datetime import datetime


LOG_FILE = "logs/responsible_ai_log.csv"


def save_review(case_id, ai_diagnosis, decision, correction=""):

    os.makedirs("logs", exist_ok=True)

    file_exists = os.path.exists(LOG_FILE)

    with open(LOG_FILE, "a", newline="", encoding="utf-8") as file:

        writer = csv.writer(file)

        if not file_exists:
            writer.writerow([
                "case_id",
                "ai_diagnosis",
                "human_decision",
                "human_correction",
                "timestamp"
            ])

        writer.writerow([
            case_id,
            ai_diagnosis,
            decision,
            correction,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ])


def main():

    print("=" * 60)
    print("             NETSAGE AI")
    print("              HUMAN REVIEW")
    print("=" * 60)

    case_id = input("\nEnter Case ID: ")

    print("\nAI Diagnosis:")
    ai_diagnosis = input("> ")

    print("\nChoose human review decision:")

    print("1. Accepted")
    print("2. Edited")
    print("3. Rejected")

    choice = input("\nEnter choice (1/2/3): ")

    if choice == "1":

        decision = "Accepted"
        correction = ""

    elif choice == "2":

        decision = "Edited"

        print("\nEnter the corrected diagnosis:")
        correction = input("> ")

    elif choice == "3":

        decision = "Rejected"

        print("\nEnter reason for rejection:")
        correction = input("> ")

    else:

        print("\nInvalid choice.")
        return

    save_review(
        case_id,
        ai_diagnosis,
        decision,
        correction
    )

    print("\n" + "=" * 60)
    print("Review saved successfully.")
    print("=" * 60)

    print(f"\nCase ID       : {case_id}")
    print(f"AI Diagnosis  : {ai_diagnosis}")
    print(f"Human Decision: {decision}")

    if correction:
        print(f"Correction    : {correction}")


if __name__ == "__main__":
    main()