import pandas as pd
import os

from demo_diagnosis import diagnose_case


INPUT_FILE = "data/cases.csv"
OUTPUT_FILE = "logs/case_results.csv"


def main():

    print("=" * 60)
    print("              NETSAGE AI")
    print("             30 CASE TEST")
    print("=" * 60)

    # Load dataset
    df = pd.read_csv(INPUT_FILE)

    print(f"\nTotal cases loaded: {len(df)}")

    results = []

    for _, row in df.iterrows():

        case_id = row["ccase_id"]
        symptom = row["symptom"]
        topology = row["topology_note"]
        show_output = row["show_output"]
        expected_fault = row["expected_fault"]

        diagnosis = diagnose_case(
            symptom,
            topology,
            show_output
        )

        predicted_fault = diagnosis["root_cause"]

        # Simple comparison
        expected_text = str(expected_fault).lower()
        predicted_text = str(predicted_fault).lower()

        correct = False

        if (
            expected_text in predicted_text
            or predicted_text in expected_text
        ):
            correct = True

        results.append({
            "case_id": case_id,
            "symptom": symptom,
            "expected_fault": expected_fault,
            "predicted_fault": predicted_fault,
            "confidence": diagnosis["confidence"],
            "osi_layer": diagnosis["osi_layer"],
            "severity": row["severity"],
            "correct": correct
        })

        status = "CORRECT" if correct else "INCORRECT"

        print(
            f"Case {case_id:>2} | "
            f"{status:<9} | "
            f"Expected: {expected_fault} | "
            f"Predicted: {predicted_fault}"
        )

    # Convert results to DataFrame
    results_df = pd.DataFrame(results)

    # Create logs directory
    os.makedirs("logs", exist_ok=True)

    # Save results
    results_df.to_csv(
        OUTPUT_FILE,
        index=False
    )

    # Calculate accuracy
    total = len(results_df)
    correct_count = results_df["correct"].sum()

    accuracy = (correct_count / total) * 100

    print("\n" + "=" * 60)
    print("                  RESULTS")
    print("=" * 60)

    print(f"\nTotal Cases     : {total}")
    print(f"Correct Cases   : {correct_count}")
    print(f"Incorrect Cases : {total - correct_count}")
    print(f"Accuracy        : {accuracy:.2f}%")

    print("\nResults saved to:")
    print(OUTPUT_FILE)

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()