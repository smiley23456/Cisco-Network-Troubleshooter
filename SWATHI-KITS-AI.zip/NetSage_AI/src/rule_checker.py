import re


def check_duplicate_ip(output):
    """
    Check whether the output indicates a duplicate IP address.
    """
    text = output.lower()

    if "duplicate" in text or "same ip" in text:
        return {
            "check": "Duplicate IP",
            "status": "ERROR",
            "message": "Possible duplicate IP address detected."
        }

    return {
        "check": "Duplicate IP",
        "status": "PASS",
        "message": "No duplicate IP indication found."
    }


def check_subnet_mask(output):
    """
    Check for common wrong subnet mask indications.
    """
    text = output.lower()

    if "wrong subnet" in text or "incorrect mask" in text:
        return {
            "check": "Subnet Mask",
            "status": "ERROR",
            "message": "Possible incorrect subnet mask."
        }

    return {
        "check": "Subnet Mask",
        "status": "PASS",
        "message": "No incorrect subnet mask indication found."
    }


def check_gateway(output):
    """
    Check whether the output indicates a gateway mismatch.
    """
    text = output.lower()

    if "wrong gateway" in text or "gateway mismatch" in text:
        return {
            "check": "Default Gateway",
            "status": "ERROR",
            "message": "Possible default gateway mismatch."
        }

    return {
        "check": "Default Gateway",
        "status": "PASS",
        "message": "No gateway mismatch indication found."
    }


def check_interface(output):
    """
    Check for interfaces that are administratively down or down/down.
    """
    text = output.lower()

    if "administratively down" in text:
        return {
            "check": "Interface Status",
            "status": "ERROR",
            "message": "Interface is administratively down."
        }

    if "down/down" in text or "down down" in text:
        return {
            "check": "Interface Status",
            "status": "ERROR",
            "message": "Interface appears to be down."
        }

    return {
        "check": "Interface Status",
        "status": "PASS",
        "message": "No interface-down error detected."
    }


def check_vlan(output):
    """
    Check for missing VLAN indications.
    """
    text = output.lower()

    if "vlan is missing" in text or "missing vlan" in text:
        return {
            "check": "VLAN",
            "status": "ERROR",
            "message": "Possible missing VLAN."
        }

    return {
        "check": "VLAN",
        "status": "PASS",
        "message": "No missing VLAN indication found."
    }


def check_route(output):
    """
    Check for missing route indications.
    """
    text = output.lower()

    if "no route" in text or "missing route" in text:
        return {
            "check": "Routing",
            "status": "ERROR",
            "message": "Possible missing route."
        }

    return {
        "check": "Routing",
        "status": "PASS",
        "message": "No missing route indication found."
    }


def run_all_checks(output):
    """
    Run all deterministic network checks.
    """

    results = []

    results.append(check_duplicate_ip(output))
    results.append(check_subnet_mask(output))
    results.append(check_gateway(output))
    results.append(check_interface(output))
    results.append(check_vlan(output))
    results.append(check_route(output))

    return results


def print_results(results):
    """
    Display the results in a readable format.
    """

    print("\n" + "=" * 60)
    print("          NETSAGE AI - RULE CHECKER")
    print("=" * 60)

    for result in results:

        print(f"\nCheck   : {result['check']}")
        print(f"Status  : {result['status']}")
        print(f"Message : {result['message']}")

    print("\n" + "=" * 60)


if __name__ == "__main__":

    print("NetSage AI Rule Checker")
    print("-----------------------")

    print("\nEnter Cisco show-command output.")
    print("Type END on a new line when finished.\n")

    lines = []

    while True:

        line = input()

        if line.strip().upper() == "END":
            break

        lines.append(line)

    output = "\n".join(lines)

    results = run_all_checks(output)

    print_results(results)