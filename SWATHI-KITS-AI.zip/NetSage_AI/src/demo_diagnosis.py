import json


def make_result(root_cause, confidence, layer, evidence, commands, fixes):
    return {
        "root_cause": root_cause,
        "confidence": confidence,
        "osi_layer": layer,
        "evidence": evidence,
        "next_command": commands,
        "fix_steps": fixes,
        "human_review_required": True
    }


def diagnose_case(symptom, topology, show_output):

    text = (
        symptom + " " +
        topology + " " +
        show_output
    ).lower()

    # 1. Wrong VLAN assignment
    if "fa0/1 is in vlan 20" in text or "fa0/1 is assigned to vlan 20" in text:
        return make_result(
            "Wrong VLAN assignment", "High", "Layer 2",
            ["Fa0/1 is assigned to VLAN 20."],
            ["show vlan brief", "show interfaces switchport"],
            ["Verify the required VLAN.", "Assign Fa0/1 to the correct VLAN.", "Test connectivity."]
        )

    # 2. Missing VLAN
    if "vlan 10 is missing" in text:
        return make_result(
            "Missing VLAN", "High", "Layer 2",
            ["VLAN 10 is missing from the switch."],
            ["show vlan brief"],
            ["Create VLAN 10 if authorized.", "Verify VLAN membership.", "Test connectivity."]
        )

    # 3. Trunk misconfiguration
    if "is not trunking" in text:
        return make_result(
            "Trunk misconfiguration", "High", "Layer 2",
            ["The interface is not operating as a trunk."],
            ["show interfaces trunk", "show interfaces switchport"],
            ["Verify trunk configuration.", "Verify trunk mode.", "Test connectivity."]
        )

    # 4. Access port wrong VLAN
    if "switchport access vlan 20" in text:
        return make_result(
            "Access port assigned to wrong VLAN", "High", "Layer 2",
            ["The access port is configured for VLAN 20."],
            ["show running-config", "show vlan brief"],
            ["Verify the intended VLAN.", "Assign the access port to the correct VLAN.", "Test connectivity."]
        )

    # 5. Wrong default gateway
    if "default gateway 192.168.2.1" in text:
        return make_result(
            "Wrong default gateway", "High", "Layer 3",
            ["The PC uses default gateway 192.168.2.1."],
            ["ipconfig", "show ip interface brief"],
            ["Verify the correct gateway.", "Correct the PC gateway.", "Test connectivity."]
        )

    # 6. Gateway interface down
    if "g0/0 administratively down" in text:
        return make_result(
            "Gateway interface is down", "High", "Layer 3",
            ["G0/0 is administratively down."],
            ["show ip interface brief"],
            ["Check G0/0.", "Enable the interface if appropriate.", "Test connectivity."]
        )

    # 7. DHCP server unavailable
    if "169.254.10.5" in text:
        return make_result(
            "DHCP server unavailable", "High", "Layer 3",
            ["The PC received a 169.254.x.x address."],
            ["ipconfig", "show ip dhcp pool"],
            ["Verify DHCP server availability.", "Check DHCP connectivity.", "Renew the IP address."]
        )

    # 8. Incorrect DHCP network
    if "show ip dhcp pool" in text and "192.168.20.0/24" in text:
        return make_result(
            "Incorrect DHCP network configuration", "High", "Layer 3",
            ["The DHCP pool uses network 192.168.20.0/24."],
            ["show ip dhcp pool", "show running-config"],
            ["Verify the intended DHCP network.", "Correct the DHCP network.", "Renew the client address."]
        )

    # 9. DHCP pool exhausted
    if "addresses leased 254" in text:
        return make_result(
            "DHCP pool exhausted", "High", "Layer 3",
            ["The DHCP pool has 254 leased addresses."],
            ["show ip dhcp pool"],
            ["Check available addresses.", "Review pool size.", "Release unused leases if appropriate."]
        )

    # 10. DNS server unreachable
    if "dns server 192.168.10.50" in text and "unreachable" in text:
        return make_result(
            "DNS server unreachable", "High", "Layer 7",
            ["DNS server 192.168.10.50 is unreachable."],
            ["ipconfig /all", "ping 192.168.10.50"],
            ["Verify DNS server connectivity.", "Check routing.", "Test name resolution."]
        )

    # 11. Wrong DNS server
    if "dns server 192.168.20.1" in text:
        return make_result(
            "Wrong DNS server address", "High", "Layer 7",
            ["The configured DNS server address is incorrect."],
            ["ipconfig /all"],
            ["Verify the correct DNS server.", "Correct DNS configuration.", "Test name resolution."]
        )

    # 12. Missing route
    if "no route to 10.10.20.0/24" in text:
        return make_result(
            "Missing route", "High", "Layer 3",
            ["No route exists to 10.10.20.0/24."],
            ["show ip route"],
            ["Identify the destination network.", "Configure the required route.", "Verify routing."]
        )

    # 13. Incorrect static route
    if "static route" in text and "via 192.168.2.5" in text:
        return make_result(
            "Incorrect static route", "High", "Layer 3",
            ["The static route uses next hop 192.168.2.5."],
            ["show ip route", "show running-config"],
            ["Verify the correct next hop.", "Correct the static route.", "Test connectivity."]
        )

    # 14. Routing interface down
    if "serial0/0/0 down/down" in text:
        return make_result(
            "Routing interface is down", "High", "Layer 3",
            ["Serial0/0/0 is down/down."],
            ["show ip interface brief"],
            ["Check the WAN interface.", "Verify cable and configuration.", "Test routing."]
        )

    # 15. OSPF neighbor failure
    if "ospf neighbor" in text and "no neighbors" in text:
        return make_result(
            "OSPF neighbor relationship failure", "High", "Layer 3",
            ["No OSPF neighbors are established."],
            ["show ip ospf neighbor", "show ip ospf interface"],
            ["Verify OSPF configuration.", "Check area settings.", "Verify neighbor formation."]
        )

    # 16. ACL blocking traffic
    if "deny ip 192.168.10.0" in text:
        return make_result(
            "ACL blocking traffic", "High", "Layer 3/4",
            ["The ACL contains a deny rule blocking the server traffic."],
            ["show access-lists", "show running-config"],
            ["Identify the blocking rule.", "Review the security policy.", "Correct the ACL if authorized.", "Test traffic."]
        )

    # 17. ACL wrong interface/direction
    if "ip access-group 101 out on g0/0" in text:
        return make_result(
            "ACL applied to wrong interface or direction", "High", "Layer 3/4",
            ["ACL 101 is applied outbound on G0/0."],
            ["show running-config", "show access-lists"],
            ["Verify intended interface.", "Verify direction.", "Correct ACL application.", "Test traffic."]
        )

    # 18. Missing ACL permit
    if "no permit tcp" in text and "eq 80" in text:
        return make_result(
            "Missing ACL permit rule", "High", "Layer 3/4",
            ["No permit rule exists for HTTP traffic on port 80."],
            ["show access-lists"],
            ["Review ACL entries.", "Add the required permit rule according to policy.", "Test HTTP traffic."]
        )

    # 19. NAT configuration missing
    if "no ip nat inside source command" in text:
        return make_result(
            "NAT configuration missing", "High", "Layer 3",
            ["No ip nat inside source command is configured."],
            ["show running-config", "show ip nat translations"],
            ["Verify NAT requirements.", "Configure NAT according to the design.", "Verify translations."]
        )

    # 20. Incorrect NAT configuration
    if "incorrect inside local mapping" in text:
        return make_result(
            "Incorrect NAT configuration", "High", "Layer 3",
            ["The inside local NAT mapping is incorrect."],
            ["show ip nat translations"],
            ["Review NAT mappings.", "Correct the NAT configuration.", "Test connectivity."]
        )

    # 21. NAT overload/PAT
    if "ip nat inside source static" in text:
        return make_result(
            "NAT overload/PAT not configured correctly", "High", "Layer 3",
            ["Static NAT is configured instead of the required shared public-IP translation."],
            ["show running-config", "show ip nat translations"],
            ["Verify NAT overload/PAT.", "Configure PAT according to the design.", "Test multiple clients."]
        )

    # 22. Wireless VLAN mapping
    if "wireless vlan mapping missing" in text:
        return make_result(
            "Wireless VLAN mapping problem", "High", "Layer 2",
            ["Wireless VLAN mapping is missing."],
            ["show vlan brief", "show running-config"],
            ["Verify SSID-to-VLAN mapping.", "Configure the required VLAN mapping.", "Test wireless access."]
        )

    # 23. Wireless authentication
    if "incorrect wireless security settings" in text:
        return make_result(
            "Wireless authentication configuration problem", "High", "Layer 2",
            ["Wireless security settings are incorrect."],
            ["show running-config"],
            ["Verify authentication settings.", "Correct wireless security configuration.", "Test authentication."]
        )

    # 24. Guest isolation
    if "no deny rule for guest-to-internal traffic" in text:
        return make_result(
            "Guest isolation failure", "High", "Layer 3/4",
            ["No ACL deny rule exists for guest-to-internal traffic."],
            ["show access-lists"],
            ["Review guest isolation policy.", "Configure the required ACL rule.", "Test guest isolation."]
        )

    # 25. Duplicate IP
    if "same ip associated with different mac" in text:
        return make_result(
            "Duplicate IP address", "High", "Layer 3",
            ["The same IP address is associated with different MAC addresses."],
            ["show arp"],
            ["Identify the duplicate host.", "Correct the IP assignment.", "Test connectivity."]
        )

    # 26. Wrong subnet mask
    if "mask 255.255.0.0" in text and "uses /24" in text:
        return make_result(
            "Wrong subnet mask", "High", "Layer 3",
            ["The PC uses 255.255.0.0 while the network requires /24."],
            ["ipconfig"],
            ["Correct the subnet mask to match the network.", "Verify IP configuration.", "Test connectivity."]
        )

    # 27. Interface administratively down
    if "fa0/10 status: administratively down" in text:
        return make_result(
            "Interface administratively down", "High", "Layer 2/3",
            ["Fa0/10 is administratively down."],
            ["show interfaces Fa0/10 status"],
            ["Check interface status.", "Enable the interface if appropriate.", "Test connectivity."]
        )

    # 28. VLAN missing from trunk allowed list
    if "allowed 10,30 but not 20" in text:
        return make_result(
            "VLAN missing from trunk allowed list", "High", "Layer 2",
            ["VLAN 20 is missing from the trunk allowed list."],
            ["show interfaces trunk"],
            ["Add VLAN 20 to the allowed list if authorized.", "Verify trunk status.", "Test connectivity."]
        )

    # 29. Inter-VLAN routing interface problem
    if "g0/0.20 is down" in text:
        return make_result(
            "Inter-VLAN routing interface problem", "High", "Layer 3",
            ["Subinterface G0/0.20 is down."],
            ["show ip interface brief", "show running-config"],
            ["Verify the subinterface.", "Check encapsulation and IP configuration.", "Test inter-VLAN connectivity."]
        )

    # 30. ACL blocking inter-VLAN traffic
    if "show ip route contains destination" in text and "show access-lists shows deny" in text:
        return make_result(
            "ACL blocking inter-VLAN traffic", "High", "Layer 3/4",
            ["The destination route exists but an ACL contains a deny rule."],
            ["show access-lists", "show running-config"],
            ["Review the inter-VLAN ACL.", "Verify required traffic is permitted.", "Test connectivity."]
        )

    return make_result(
        "Unable to determine",
        "Low",
        "Unknown",
        ["Insufficient evidence to determine the root cause."],
        ["Collect additional show-command output"],
        ["Gather more evidence before changing configuration."]
    )


def main():

    print("=" * 60)
    print("              NETSAGE AI")
    print("       Cisco Network Troubleshooter")
    print("=" * 60)

    print("\nEnter the network symptom:")
    symptom = input("> ")

    print("\nEnter the topology information:")
    topology = input("> ")

    print("\nEnter Cisco show-command output.")
    print("Type END when finished:\n")

    lines = []

    while True:
        line = input()

        if line.strip().upper() == "END":
            break

        lines.append(line)

    show_output = "\n".join(lines)

    print("\nAnalyzing...")

    result = diagnose_case(
        symptom,
        topology,
        show_output
    )

    print("\n" + "=" * 60)
    print("                 AI DIAGNOSIS")
    print("=" * 60)

    print(json.dumps(result, indent=4))

    print("\n" + "=" * 60)
    print("          HUMAN REVIEW REQUIRED")
    print("=" * 60)


if __name__ == "__main__":
    main()