import os
import json
from openai import OpenAI


# Create OpenAI client
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


SYSTEM_PROMPT = """
You are NetSage AI, an AI-assisted Cisco network troubleshooting helper.

Analyze the provided network symptom, topology information, and Cisco
show-command output.

Your job is to identify the most likely network fault.

IMPORTANT:
- Use only the evidence provided.
- Do not invent evidence.
- If the evidence is insufficient, say so.
- Always recommend the next command needed for confirmation.
- Never claim that a fix has been verified without verification evidence.
- A human network engineer must review every diagnosis.

Return ONLY valid JSON using these fields:

{
  "root_cause": "",
  "confidence": "",
  "osi_layer": "",
  "evidence": [],
  "next_command": [],
  "fix_steps": [],
  "human_review_required": true
}

Confidence must be High, Medium, or Low.
"""


def diagnose_network_problem(symptom, topology, show_output):

    user_prompt = f"""
NETWORK SYMPTOM:
{symptom}

TOPOLOGY:
{topology}

CISCO SHOW-COMMAND OUTPUT:
{show_output}

Analyze this case and return the diagnosis as JSON.
"""

    response = client.responses.create(
        model="gpt-5.6-luna",
        instructions=SYSTEM_PROMPT,
        input=user_prompt
    )

    result = response.output_text

    return result


def main():

    print("=" * 60)
    print("              NETSAGE AI")
    print("       Cisco Network Troubleshooter")
    print("=" * 60)

    print("\nEnter the network symptom:")
    symptom = input("> ")

    print("\nEnter the topology information:")
    topology = input("> ")

    print("\nEnter Cisco show-command output.")
    print("Type END when finished:\n")

    lines = []

    while True:

        line = input()

        if line.strip().upper() == "END":
            break

        lines.append(line)

    show_output = "\n".join(lines)

    print("\nAnalyzing network problem...")
    print("Please wait...\n")

    try:

        diagnosis = diagnose_network_problem(
            symptom,
            topology,
            show_output
        )

        print("=" * 60)
        print("              AI DIAGNOSIS")
        print("=" * 60)

        try:
            parsed = json.loads(diagnosis)

            print(json.dumps(parsed, indent=4))

        except json.JSONDecodeError:

            print(diagnosis)

        print("\n" + "=" * 60)
        print("IMPORTANT: HUMAN REVIEW REQUIRED")
        print("=" * 60)

    except Exception as error:

        print("\nERROR:")
        print(error)


if __name__ == "__main__":
    main()